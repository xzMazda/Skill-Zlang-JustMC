# render_model.py — локальный 3D-превьюер моделей ZLite с ТЕКСТУРАМИ блоков
# Каждая грань разбивается на ячейки 1/16 блока (как пиксели текстуры Minecraft),
# каждая ячейка — отдельный полигон с процедурной текстурой и освещением.
# Сортировка по глубине поячеечно (painter's algorithm), отсечение задних граней.
# Так превью показывает и растянутые текстуры — то, что увидит игрок.
# Запуск: python3 render_model.py chest_display.zl preview.png

import re
import sys
import numpy as np
from PIL import Image, ImageDraw, ImageFont

PART_RE = re.compile(
    r'^(?:часть|part)\s+"([^"]+)"'
    r'(?:\s+размер\s+\(([^)]*)\))?'
    r'(?:\s+сдвиг\s+\(([^)]*)\))?'
    r'(?:\s+поворот\s+\(([^)]*)\))?'
    r'(?:\s+свечение\s+"([^"]+)")?$'
)

PX = 16          # пикселей текстуры на блок
MAX_CELLS = 44   # максимум ячеек на грань по оси (производительность)


def tex_dark_oak(pu, pv):
    row, r = pv // 4, pv % 4
    v = ((pu * 7 + row * 31) % 9) - 4
    if r == 0:
        c = (44 + v, 31 + v, 19 + v)
    else:
        c = (63 + v, 46 + v, 29 + v)
        if (pu * 13 + pv * 5) % 17 == 0:
            c = (52 + v, 37 + v, 23 + v)
    return c


def tex_spruce(pu, pv):
    row, r = pv // 4, pv % 4
    v = ((pu * 11 + row * 17) % 7) - 3
    if r == 0:
        c = (74 + v, 53 + v, 33 + v)
    else:
        c = (109 + v, 80 + v, 51 + v)
    return c


def tex_gold(pu, pv):
    if pu % 8 == 0 or pv % 8 == 0:
        return (168, 128, 26)
    if pu % 8 in (2, 3) and pv % 8 in (2, 3):
        return (255, 238, 138)
    return (247, 207, 61)


def tex_blackstone(pu, pv):
    h = (pu * 29 + pv * 61) % 23
    if h < 4:
        return (18, 16, 20)
    if h < 7:
        return (48, 44, 52)
    return (30, 27, 33)


def tex_oak_log(pu, pv):
    h = (pu * 31 + 7) % 6
    v = ((pu * 11 + pv * 3) % 5) - 2
    if h < 2:
        return (66 + v, 48 + v, 28 + v)
    return (104 + v, 78 + v, 46 + v)


def tex_oak_leaves(pu, pv):
    h = (pu * 17 + pv * 41) % 10
    if h < 2:
        return (34, 74, 28)
    if h < 8:
        return (58, 112, 44)
    return (88, 144, 60)


def flat(rgb):
    def f(pu, pv):
        v = ((pu * 7 + pv * 13) % 3) - 1
        return (max(0, rgb[0] + v), max(0, rgb[1] + v), max(0, rgb[2] + v))
    return f


TEX = {
    'dark_oak_planks': tex_dark_oak,
    'spruce_planks': tex_spruce,
    'gold_block': tex_gold,
    'blackstone': tex_blackstone,
    'oak_planks': tex_spruce,
    'oak_log': tex_oak_log,
    'oak_leaves': tex_oak_leaves,
    'lantern': lambda u, v: ((232, 190, 96) if (u + v) % 5 else (190, 150, 70)),
    'smooth_stone': flat((126, 126, 126)),
    'quartz_block': flat((236, 233, 228)),
    'iron_block': flat((214, 214, 214)),
    'white_concrete': flat((207, 213, 214)),
    'light_gray_concrete': flat((125, 125, 115)),
    'gray_concrete': flat((54, 57, 61)),
    'black_concrete': flat((12, 14, 18)),
    'red_concrete': flat((142, 33, 33)),
    'orange_concrete': flat((224, 97, 0)),
    'yellow_concrete': flat((241, 175, 21)),
    'lime_concrete': flat((94, 168, 24)),
    'green_concrete': flat((84, 109, 27)),
    'brown_concrete': flat((96, 60, 32)),
    'pink_concrete': flat((214, 127, 151)),
    'light_blue_concrete': flat((58, 175, 217)),
    'blue_concrete': flat((44, 46, 143)),
}


def parse_parts(path):
    parts = []
    for raw in open(path, encoding='utf-8'):
        line = raw.split('#')[0].strip()
        m = PART_RE.match(line)
        if not m:
            continue
        size = [float(x) for x in (m.group(2) or '1,1,1').split(',')]
        pos = [float(x) for x in (m.group(3) or '0,0,0').split(',')]
        rot = [float(x) for x in m.group(4).split(',')] if m.group(4) else None
        parts.append((m.group(1), size, pos, bool(m.group(5)), rot))
    return parts


def camera(azim_deg, elev_deg):
    a, e = np.radians(azim_deg), np.radians(elev_deg)
    fwd = -np.array([np.cos(e) * np.sin(a), np.sin(e), np.cos(e) * np.cos(a)])
    right = np.cross(fwd, [0, 1, 0])
    right /= np.linalg.norm(right)
    up = np.cross(right, fwd)
    return fwd, right, up


def box_quads(size, pos):
    """Грани бокса: 4 вершины в порядке (u,v)=(0,0),(1,0),(1,1),(0,1), нормаль,
    длины граней по u и v в блоках (для плотности текстуры)."""
    sx, sy, sz = size
    cx, cy, cz = pos
    hx, hy, hz = sx / 2, sy / 2, sz / 2
    v = np.array([
        [cx - hx, cy - hy, cz - hz], [cx + hx, cy - hy, cz - hz],
        [cx + hx, cy + hy, cz - hz], [cx - hx, cy + hy, cz - hz],
        [cx - hx, cy - hy, cz + hz], [cx + hx, cy - hy, cz + hz],
        [cx + hx, cy + hy, cz + hz], [cx - hx, cy + hy, cz + hz],
    ])
    return [
        (v[[0, 1, 2, 3]], (0, 0, -1), sx, sy),   # зад: u=x, v=y
        (v[[5, 4, 7, 6]], (0, 0, 1), sx, sy),    # перед
        (v[[4, 0, 3, 7]], (-1, 0, 0), sz, sy),   # лево: u=z, v=y
        (v[[1, 5, 6, 2]], (1, 0, 0), sz, sy),    # право
        (v[[3, 2, 6, 7]], (0, 1, 0), sx, sz),    # верх: u=x, v=z
        (v[[4, 5, 1, 0]], (0, -1, 0), sx, sz),   # низ
    ]


def collect_cells(parts):
    """Все ячейки всех граней: (нормаль, pu, pv, вершины, текстура, glow)."""
    cells = []
    for block, size, pos, glow, _rot in parts:
        tex = TEX.get(block)
        for verts, n, su, sv in box_quads(size, pos):
            n = np.array(n, float)
            P00, P10, P11, P01 = verts
            nu = max(1, min(MAX_CELLS, round(su * PX)))
            nv = max(1, min(MAX_CELLS, round(sv * PX)))
            us = np.linspace(0, 1, nu + 1)
            vs = np.linspace(0, 1, nv + 1)
            for i in range(nu):
                for j in range(nv):
                    u0, u1, v0, v1 = us[i], us[i + 1], vs[j], vs[j + 1]

                    def pt(u, v):
                        return (P00 * (1 - u) * (1 - v) + P10 * u * (1 - v)
                                + P11 * u * v + P01 * (1 - u) * v)

                    quad = [pt(u0, v0), pt(u1, v0), pt(u1, v1), pt(u0, v1)]
                    cells.append((n, (u0 + u1) / 2 * su * PX, (v0 + v1) / 2 * sv * PX,
                                  quad, tex, glow))
    return cells


def render_view(cells, fwd, right, up, size=(760, 620)):
    light = np.array([0.45, 0.8, 0.35])
    light = light - fwd * np.dot(light, fwd)
    light /= np.linalg.norm(light)
    polys = []
    all_pts = []
    for n, pu, pv, quad, tex, glow in cells:
        if np.dot(n, fwd) >= 0:
            continue
        depth = np.mean(np.array(quad) @ fwd)
        ndl = max(0.0, float(np.dot(n, light)))
        k = 0.5 + 0.6 * ndl
        r, g, b = tex(int(pu), int(pv))
        col = (min(255, int(r * k)), min(255, int(g * k)), min(255, int(b * k)))
        pts2d = [(np.dot(p, right), np.dot(p, up)) for p in quad]
        polys.append((depth, pts2d, col, glow))
        all_pts.extend(pts2d)
    polys.sort(key=lambda q: -q[0])
    xs = [p[0] for p in all_pts]
    ys = [p[1] for p in all_pts]
    margin = 40
    kk = min((size[0] - 2 * margin) / (max(xs) - min(xs)),
             (size[1] - 2 * margin) / (max(ys) - min(ys)))
    ox = (size[0] - kk * (max(xs) + min(xs))) / 2
    oy = (size[1] + kk * (max(ys) + min(ys))) / 2
    img = Image.new('RGB', size, (245, 246, 248))
    dr = ImageDraw.Draw(img)
    for _, pts, col, glow in polys:
        scr = [(ox + kk * x, oy - kk * y) for x, y in pts]
        dr.polygon(scr, fill=col)
    return img


def render(parts, out):
    cells = collect_cells(parts)
    views = [('три четверти слева', 38, 16), ('три четверти справа', -38, 16), ('сверху-спереди', 0, 38)]
    imgs = [render_view(cells, *camera(a, e)) for _, a, e in views]
    w, h = imgs[0].size
    canvas = Image.new('RGB', (w * 3 + 40, h + 50), (245, 246, 248))
    font = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf', 18)
    dr = ImageDraw.Draw(canvas)
    for i, (title, _, _) in enumerate(views):
        canvas.paste(imgs[i], (i * (w + 20), 50))
        dr.text((i * (w + 20) + 15, 15), title, fill=(40, 40, 40), font=font)
    canvas.save(out)
    print('saved', out, '| parts:', len(parts), '| cells:', len(cells))


if __name__ == '__main__':
    src, out = sys.argv[1], sys.argv[2]
    pts = parse_parts(src)
    if not pts:
        sys.exit('не нашёл ни одной части — проверь файл')
    render(pts, out)
