# -*- coding: utf-8 -*-
"""Режет склеенный shop_empire.zl обратно на 3 модуля (обходит лимит импорта JustMC).

shop_empire.zl = shop_models.zl (строки 1-232) + часть 1 (233-643) + часть 2 (644-end).
Вызовы code::call_function работают между модулями одного мира, поэтому резать безопасно.
"""
import io

SRC = 'shop_empire.zl'

with io.open(SRC, encoding='utf-8') as f:
    lines = f.readlines()  # 0-based; строка N файла = lines[N-1]

models = lines[0:232]    # 1-232
# граница части 2 — динамическая (строки выше сдвигаются при правках)
p2 = next(i for i, ln in enumerate(lines) if 'часть 2' in ln)
game_a = lines[232:p2 - 1]  # до "# ====" перед заголовком части 2
game_b = lines[p2 - 1:]     # от "# ====" части 2 до конца

with io.open('shop_models.zl', 'w', encoding='utf-8') as f:
    f.writelines(models)
with io.open('game_a.zl', 'w', encoding='utf-8') as f:
    f.writelines(game_a)

# game_b ещё режем пополам: постройка/меню и покупатели/NPC/триггеры —
# чтобы каждая часть была заведомо меньше крупнейшего импортировавшегося модуля
cust_at = None
for i, ln in enumerate(game_b):
    if 'покупатель: спавн с меткой' in ln:
        cust_at = i
        break
if cust_at is None:
    raise SystemExit('граница покупателей в game_b не найдена')
game_b1 = game_b[:cust_at]
game_b2 = ['# SHOP EMPIRE — часть 3: покупатели, NPC, HUD, триггеры\n'] + game_b[cust_at:]
with io.open('game_b.zl', 'w', encoding='utf-8') as f:
    f.writelines(game_b1)
with io.open('game_c.zl', 'w', encoding='utf-8') as f:
    f.writelines(game_b2)

for name, part in (('shop_models', models), ('game_a', game_a),
                   ('game_b', game_b1), ('game_c', game_b2)):
    print(f'{name}: {len(part)} строк')
