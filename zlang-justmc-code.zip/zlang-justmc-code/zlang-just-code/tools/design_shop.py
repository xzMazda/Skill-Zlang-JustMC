# design_shop.py — модели магазина Shop Empire: полка, полка для фруктов,
# холодильник мяса, касса. Все части БЕЗ поворотов (размеры уже вдоль осей),
# поэтому антибаг точен при любой конвенции углов.
# Повороты модели — 4 варианта (0/90/180/270 вокруг Y, конвенция A: (x,z)->(z,-x)):
# размеры меняются местами на нечётных, центры поворачиваются.
#   python3 design_shop.py
#   python3 render_model.py polka_preview.zl preview_polka.png   (и т.д.)
#   python3 zlang.py shop_models.zl && python3 check_model.py shop_models.zl shop_models.jc

def num(v):
    return f'{round(v, 3):g}'


MODELS = {
    # ===== ПОЛКА (2 x 0.6 x 1.7) — напитки и снеки =====
    'polka': [
        ('dark_oak_planks', 2.0, 0.12, 0.6, 0, 0.06, 0),        # цоколь
        ('dark_oak_planks', 2.0, 1.5, 0.08, 0, 0.87, -0.26),    # задник
        ('dark_oak_planks', 0.1, 1.58, 0.6, -0.95, 0.91, 0),    # лево
        ('dark_oak_planks', 0.1, 1.58, 0.6, 0.95, 0.91, 0),     # право
        ('dark_oak_planks', 1.8, 0.07, 0.5, 0, 0.55, 0),        # полка 1
        ('dark_oak_planks', 1.8, 0.07, 0.5, 0, 1.15, 0),        # полка 2
        ('dark_oak_planks', 2.0, 0.09, 0.62, 0, 1.66, 0),       # крышка
        ('black_concrete', 0.24, 0.3, 0.24, -0.65, 0.73, 0.05),   # кола
        ('black_concrete', 0.24, 0.3, 0.24, -0.3, 0.73, 0.05),    # кола
        ('light_blue_concrete', 0.24, 0.3, 0.24, 0.1, 0.73, 0.05), # вода
        ('orange_concrete', 0.24, 0.3, 0.24, 0.45, 0.73, 0.05),   # сок
        ('yellow_concrete', 0.3, 0.24, 0.24, -0.5, 1.3, 0.05),    # чипсы
        ('yellow_concrete', 0.3, 0.24, 0.24, -0.1, 1.3, 0.05),    # чипсы
        ('brown_concrete', 0.3, 0.24, 0.24, 0.35, 1.3, 0.05),     # печенье
    ],
    # ===== ПОЛКА ДЛЯ ФРУКТОВ (2 x 0.6 x 1.5) =====
    'polka_frukty': [
        ('spruce_planks', 2.0, 0.12, 0.6, 0, 0.06, 0),
        ('spruce_planks', 0.1, 1.35, 0.6, -0.95, 0.79, 0),
        ('spruce_planks', 0.1, 1.35, 0.6, 0.95, 0.79, 0),
        ('spruce_planks', 2.0, 1.3, 0.08, 0, 0.77, -0.26),
        ('spruce_planks', 1.8, 0.08, 0.55, 0, 0.5, 0),
        ('spruce_planks', 1.8, 0.08, 0.55, 0, 1.05, 0),
        ('spruce_planks', 2.0, 0.09, 0.62, 0, 1.42, 0),
        ('red_concrete', 0.24, 0.24, 0.24, -0.6, 0.66, 0.03),     # яблоко
        ('red_concrete', 0.24, 0.24, 0.24, -0.2, 0.66, 0.03),     # яблоко
        ('orange_concrete', 0.24, 0.24, 0.24, 0.2, 0.66, 0.03),   # апельсин
        ('lime_concrete', 0.24, 0.24, 0.24, 0.6, 0.66, 0.03),     # лайм
        ('yellow_concrete', 0.28, 0.22, 0.22, -0.5, 1.21, 0.03),  # банан
        ('red_concrete', 0.24, 0.24, 0.24, 0.0, 1.21, 0.03),      # яблоко
        ('green_concrete', 0.24, 0.24, 0.24, 0.45, 1.21, 0.03),   # груша
    ],
    # ===== ХОЛОДИЛЬНИК МЯСА (1.1 x 0.85 x 2.2) — открытая витрина =====
    'holodilnik': [
        ('white_concrete', 1.0, 0.1, 0.75, 0, 0.05, 0),           # низ
        ('white_concrete', 1.0, 2.0, 0.1, 0, 1.1, -0.35),         # зад
        ('white_concrete', 0.1, 2.0, 0.75, -0.45, 1.1, 0),        # лево
        ('white_concrete', 0.1, 2.0, 0.75, 0.45, 1.1, 0),         # право
        ('white_concrete', 1.0, 0.1, 0.75, 0, 2.15, 0),           # топ
        ('light_gray_concrete', 1.0, 0.12, 0.1, 0, 1.95, 0.36),   # морозилка
        ('smooth_stone', 0.85, 0.06, 0.55, 0, 0.85, 0.02),        # полка 1
        ('smooth_stone', 0.85, 0.06, 0.55, 0, 1.45, 0.02),        # полка 2
        ('red_concrete', 0.26, 0.22, 0.26, -0.25, 0.99, 0.02),    # мясо
        ('brown_concrete', 0.26, 0.22, 0.26, 0.08, 0.99, 0.02),   # мясо
        ('red_concrete', 0.26, 0.22, 0.26, 0.32, 0.99, 0.02),     # мясо
        ('pink_concrete', 0.26, 0.22, 0.26, -0.2, 1.59, 0.02),    # мясо
        ('pink_concrete', 0.26, 0.22, 0.26, 0.18, 1.59, 0.02),    # мясо
        ('iron_block', 0.06, 0.5, 0.06, 0.38, 1.2, 0.42),         # ручка
    ],
    # ===== КАССА (1.3 x 0.85 x 1.1) =====
    'kassa': [
        ('dark_oak_planks', 1.2, 0.85, 0.75, 0, 0.43, 0),         # тумба
        ('quartz_block', 1.28, 0.08, 0.82, 0, 0.9, 0),            # столешница
        ('blackstone', 0.45, 0.3, 0.38, -0.25, 1.09, -0.1),       # регистр
        ('light_blue_concrete', 0.4, 0.28, 0.05, -0.25, 1.34, -0.27),  # экран
        ('gray_concrete', 0.3, 0.05, 0.22, -0.25, 0.97, 0.12),    # клавиатура
        ('gold_block', 0.2, 0.12, 0.15, 0.3, 1.0, -0.05),         # ящик монет
    ],
}


def rot_c(x, y, z, k):
    """Центр при повороте k*90° вокруг Y (конвенция A: (x,z) -> (z,-x))."""
    for _ in range(k % 4):
        x, z = z, -x
    return x, y, z


def rot_s(sx, sy, sz, k):
    """Размеры при повороте вокруг Y: на нечётных шагах sx и sz меняются местами."""
    if k % 2 == 1:
        return sz, sy, sx
    return sx, sy, sz


def emit_model(lines, disp_name, parts, k, anchor):
    lines.append(f'модель {disp_name}_{[0, 90, 180, 270][k]} at {anchor}:')
    for block, sx, sy, sz, x, y, z in parts:
        nx, ny, nz = rot_c(x, y, z, k)
        nsx, nsy, nsz = rot_s(sx, sy, sz, k)
        lines.append(f'    часть "{block}" размер ({num(nsx)}, {num(nsy)}, {num(nsz)}) '
                     f'сдвиг ({num(nx)}, {num(ny)}, {num(nz)})')
    lines.append('')


# ---------- сборка shop_models.zl ----------
out = [
    '# shop_models.zl — СГЕНЕРИРОВАНО design_shop.py, руками не править!',
    '# Части без поворотов -> антибаг точен. Поворот модели = отдельные варианты _0.._270.',
    '',
    'game polka_mesto = location(0, -64, 0)',
    'game frukt_mesto = location(0, -64, 0)',
    'game holod_mesto = location(0, -64, 0)',
    'game kassa_mesto = location(0, -64, 0)',
    '',
]
total = 0
for mname, parts in MODELS.items():
    anchor = {'polka': 'polka_mesto', 'polka_frukty': 'frukt_mesto',
              'holodilnik': 'holod_mesto', 'kassa': 'kassa_mesto'}[mname]
    ks = [0] if mname == 'касса' else [0, 1, 2, 3]
    for k in ks:
        emit_model(out, mname, parts, k, anchor)
        total += len(parts)
out.append('# when world_start / join рисует кассы; полки ставит игрок')
out.append('')
open('shop_models.zl', 'w', encoding='utf-8').write('\n'.join(out))
print(f'shop_models.zl: {total} частей')

# ---------- превью по одной модели (вариант 0) ----------
for mname in MODELS:
    lines = [
        f'game mesto = location(0, -64, 0)',
        '',
        f'модель {mname} at mesto:',
    ]
    for block, sx, sy, sz, x, y, z in MODELS[mname]:
        lines.append(f'    часть "{block}" размер ({num(sx)}, {num(sy)}, {num(sz)}) '
                     f'сдвиг ({num(x)}, {num(y)}, {num(z)})')
    fn = {'polka': 'polka_preview', 'polka_frukty': 'frukt_preview',
          'holodilnik': 'holod_preview', 'kassa': 'kassa_preview'}[mname]
    open(fn + '.zl', 'w', encoding='utf-8').write('\n'.join(lines) + '\n')
print('previews: polka/frukt/holod/kassa_preview.zl')
