# -*- coding: utf-8 -*-
"""Подклеивает недостающие объявления глобалов в разрезанные части.

Цикл: компиляция части -> jmcc пишет "Неизвестный идентификатор 'X'" ->
ищем точную строку объявления X в исходном shop_empire.zl -> вставляем в топ части ->
повторяем, пока ошибки не исчезнут.
"""
import io
import re
import subprocess
import sys

def parse_decl(ln):
    """Возвращает имя переменной из строки объявления или None."""
    s = ln.strip()
    if s.startswith('save var '):
        rest = s[len('save var '):].strip()
    elif s.startswith('game var '):
        rest = s[len('game var '):].strip()
    elif s.startswith('game '):
        rest = s[len('game '):].strip()
        if rest.startswith('var '):
            return None
    else:
        return None
    if rest.startswith('`'):
        m = re.match(r'`([^`]+)`', rest)
        return m.group(1) if m else None
    m = re.match(r'([A-Za-z_][A-Za-z0-9_]*)', rest)
    return m.group(1) if m else None

ERR_RE = re.compile(r"Неизвестный идентификатор '([^']+)'")
source_lines = io.open('shop_empire.zl', encoding='utf-8').read().splitlines()

decl = {}
for ln in source_lines:
    name = parse_decl(ln)
    if name and name not in decl:
        decl[name] = ln

def compile_part(path):
    r = subprocess.run([sys.executable, 'zlang.py', path],
                       capture_output=True, text=True, timeout=300)
    out = (r.stdout or '') + (r.stderr or '')
    return out

def add_decl(path, name, line):
    with io.open(path, encoding='utf-8') as f:
        body = f.read()
    if re.search(r'`' + re.escape(name) + r'`|\b' + re.escape(name) + r'\b\s*=', body):
        # проверка: есть ли уже такая строка объявления
        for bl in body.splitlines():
            if bl.strip() == line.strip():
                return False
    with io.open(path, 'w', encoding='utf-8') as f:
        f.write(line + '\n' + body)
    return True

for path in ('game_a.zl', 'game_b.zl', 'game_c.zl', 'shop_models.zl'):
    print(f'=== {path}')
    for i in range(120):
        out = compile_part(path)
        m = ERR_RE.search(out)
        if not m:
            other = [l for l in out.splitlines() if 'Ошибка' in l or 'Error' in l]
            if other:
                print('ДРУГАЯ ОШИБКА:', other[:3])
                sys.exit(1)
            print(f'OK, чисто (итераций: {i})')
            break
        name = m.group(1)
        if name not in decl:
            print(f'НЕИЗВЕСТНО имя {name!r} — нет в объявлениях shop_empire.zl')
            sys.exit(1)
        add_decl(path, name, decl[name])
    else:
        print('Слишком много итераций')
        sys.exit(1)
